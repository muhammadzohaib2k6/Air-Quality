# Assignment No. 4 — Machine Learning Model Application & Evaluation

**Student:** MUHAMMAD ZOHAIB  
**Roll No.:** 011  
**Section:** BSCS 3A

## Project: Air Quality Measurements — Temperature Prediction

This project uses the provided `air_quality_dataset.csv` (500 rows, 10 numeric columns) to predict Temperature from nine pollutant/gas measurements.

- **Problem type:** Regression
- **Target (y):** `Temperature`
- **Features (X):** `PM2.5`, `PM10`, `NOx`, `NO2`, `SO2`, `VOCs`, `CO`, `CO2`, `CH4`
- **Models:** Linear Regression, Decision Tree Regressor, Random Forest Regressor
- **Metrics:** MAE, RMSE, R²
- **Train-test split:** 80% training (400 rows), 20% testing (100 rows), random_state=42
- **Primary metric:** RMSE; lower values indicate smaller typical errors with additional penalty for large errors.

## Results from the executed notebook

| Model | MAE | RMSE | R² |
|---|---:|---:|---:|
| Linear Regression | 1.6325 | 2.0556 | 0.4682 |
| Decision Tree Regressor | 1.6768 | 2.0736 | 0.4589 |
| Random Forest Regressor | 1.6730 | 2.1341 | 0.4268 |

**Best model on this split:** Linear Regression, because it has the lowest test RMSE (2.0556), lowest MAE (1.6325), and highest test R² (0.4682) among these three models.

The Random Forest has much higher training R² (0.8547) than test R² (0.4268), which suggests possible overfitting. The Linear Regression train-test R² gap is not large; its scores suggest moderate predictive signal rather than a perfect fit.

## How to run

1. Open `Assignment-4-Air-Quality-ML.ipynb` in Google Colab or Jupyter.
2. Keep `air_quality_dataset.csv` in the same folder.
3. Choose **Runtime → Run all** in Colab (or run all notebook cells in Jupyter).
4. Review the output tables, prediction plots, fit-check table, and final conclusion.

## Important limitation

The provided file has no explicit AQI column/class, timestamp, or location. To avoid inventing a label, this notebook treats Temperature as the continuous target and uses the pollutant columns as features. This is a modelling exercise; predictive association does not prove that pollutants cause temperature changes. The results are based on one random split and should be validated further before real-world use.
